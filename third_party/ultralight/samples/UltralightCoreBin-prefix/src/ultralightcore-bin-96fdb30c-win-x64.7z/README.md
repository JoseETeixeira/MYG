# UltralightCore - Fast, Lightweight 2D Graphics Engine

UltralightCore, the rendering engine behind Ultralight.

Source and licensing is currently proprietary, please see LICENSE.txt

For more info: https://ultralig.ht

## Building from Source

If you have source access, please see BUILDING.md in the root of the source
distribution for relevant build instructions.