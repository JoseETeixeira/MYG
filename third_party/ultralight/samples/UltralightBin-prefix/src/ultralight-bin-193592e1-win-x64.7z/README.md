# Ultralight - Binaries

This repo contains precompiled binaries for Ultralight-- a lightweight,
pure-GPU, HTML UI renderer for native apps.

Source and licensing is currently proprietary, please see LICENSE.txt

For more info: https://ultralig.ht